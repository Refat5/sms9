<!-- Footer -->
<footer id="page-footer" class="opacity-0">
    <div class="content py-20 font-size-sm clearfix">
        <div class="float-right">
            Develop <i class="fa fa-heart text-pulse"></i> By <a class="font-w600" href="https://1.envato.market/ydb" target="_blank">BizIt</a>
        </div>
        <div class="float-left">
            <a class="font-w600" href="https://1.envato.market/95j" target="_blank">BizIt BD</a> &copy; <span class="js-year-copy"></span>
        </div>
    </div>
</footer>
<!-- END Footer -->